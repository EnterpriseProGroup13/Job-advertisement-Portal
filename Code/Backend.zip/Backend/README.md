# Job Posting Website Backend API

This is a FastAPI backend implementation for a job posting website, featuring authentication, role-based access control, job listings, and applications handling.

## Features

- User authentication with JWT tokens
- Email verification for new users
- Role-based access control (Admin, Customer, Worker)
- Job posting, updating, and filtering
- Job application submission and management
- Notification system for status changes

## Project Structure

/app
  /api
    - auth.py          # Authentication endpoints
    - jobs.py          # Job listings endpoints
    - applications.py  # Applications endpoints
  /models
    - user.py          # User-related models
    - job.py           # Job-related models
    - application.py   # Application-related models
  /services
    - auth_service.py          # Authentication logic
    - job_service.py           # Job management logic
    - application_service.py   # Application management logic
    - notification_service.py  # Notification logic
    - email_service.py         # Email sending logic
  /middlewares
    - auth_middleware.py       # Authentication middleware
  /utils
    - security.py              # Security-related utilities
  - main.py                    # Application entry point
  - config.py                  # Configuration settings

## Getting Started

1. Install dependencies:
