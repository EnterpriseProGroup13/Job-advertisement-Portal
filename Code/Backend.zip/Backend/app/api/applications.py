from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import List

from app.models.application import (
    ApplicationCreate,
    ApplicationUpdate,
    ApplicationResponse,
    ApplicationStatus,
)
from app.services.application_service import (
    create_application,
    update_application,
    get_application_by_id,
    get_applications_by_job,
    get_applications_by_user,
)
from app.services.job_service import get_job_by_id
from app.services.notification_service import notify_application_status_change
from app.models.user import UserRole
from app.middlewares.auth_middleware import get_current_user, has_role

router = APIRouter(prefix="/applications")


@router.post("/", response_model=ApplicationResponse)
async def submit_application(
    application_data: ApplicationCreate,
    current_user: dict = Depends(has_role([UserRole.WORKER])),
):
    job = get_job_by_id(application_data.job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Job not found"
        )

    application = create_application(application_data.dict(), current_user["id"])
    if not application:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Failed to create application",
        )
    return application


@router.get("/job/{job_id}", response_model=List[ApplicationResponse])
async def get_applications_for_job(
    job_id: str,
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
    current_user: dict = Depends(get_current_user),
):
    job = get_job_by_id(job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Job not found"
        )

    # Only job creator or admin can see applications
    if (
        job["created_by"] != current_user["id"]
        and current_user["role"] != UserRole.ADMIN
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to view applications for this job",
        )

    applications = get_applications_by_job(job_id, limit, offset)
    return applications


@router.get("/user", response_model=List[ApplicationResponse])
async def get_user_applications(
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
    current_user: dict = Depends(get_current_user),
):
    applications = get_applications_by_user(current_user["id"], limit, offset)
    return applications


@router.get("/{application_id}", response_model=ApplicationResponse)
async def get_application_detail(
    application_id: str, current_user: dict = Depends(get_current_user)
):
    application = get_application_by_id(application_id)
    if not application:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Application not found"
        )

    job = get_job_by_id(application["job_id"])

    # Only the application creator, job creator, or admin can view an application
    if (
        application["user_id"] != current_user["id"]
        and job["created_by"] != current_user["id"]
        and current_user["role"] != UserRole.ADMIN
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to view this application",
        )

    return application


@router.put("/{application_id}", response_model=ApplicationResponse)
async def update_application_status(
    application_id: str,
    application_data: ApplicationUpdate,
    current_user: dict = Depends(get_current_user),
):
    application = get_application_by_id(application_id)
    if not application:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Application not found"
        )

    job = get_job_by_id(application["job_id"])

    # Only job creator or admin can update application status
    if (
        job["created_by"] != current_user["id"]
        and current_user["role"] != UserRole.ADMIN
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this application",
        )

    updated_application = update_application(
        application_id, application_data.dict(exclude_unset=True)
    )

    # Send notification about status change
    await notify_application_status_change(updated_application)

    return updated_application
