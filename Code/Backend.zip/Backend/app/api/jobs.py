from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import List, Optional

from app.models.job import JobCreate, JobUpdate, JobResponse, JobStatus, JobCategory
from app.services.job_service import create_job, update_job, delete_job, get_job_by_id, get_jobs
from app.models.user import UserRole
from app.middlewares.auth_middleware import get_current_user, has_role

router = APIRouter(prefix="/jobs")

@router.post("/", response_model=JobResponse)
async def create_new_job(
    job_data: JobCreate,
    current_user: dict = Depends(has_role([UserRole.CUSTOMER, UserRole.ADMIN]))
):
    return create_job(job_data.dict(), current_user["id"])

@router.get("/", response_model=List[JobResponse])
async def get_job_listings(
    category: Optional[JobCategory] = None,
    status: Optional[JobStatus] = None,
    country: Optional[str] = None,
    city: Optional[str] = None,
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
    current_user: dict = Depends(get_current_user)
):
    filters = {}
    if category:
        filters["category"] = category
    if status:
        filters["status"] = status
    if country:
        filters["location_country"] = country
    if city:
        filters["location_city"] = city
        
    return get_jobs(filters, limit, offset)

@router.get("/{job_id}", response_model=JobResponse)
async def get_job_detail(
    job_id: str,
    current_user: dict = Depends(get_current_user)
):
    job = get_job_by_id(job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found"
        )
    return job

@router.put("/{job_id}", response_model=JobResponse)
async def update_job_listing(
    job_id: str,
    job_data: JobUpdate,
    current_user: dict = Depends(get_current_user)
):
    job = get_job_by_id(job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found"
        )
        
    if job["created_by"] != current_user["id"] and current_user["role"] != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this job"
        )
        
    updated_job = update_job(job_id, job_data.dict(exclude_unset=True))
    return updated_job

@router.delete("/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_job_listing(
    job_id: str,
    current_user: dict = Depends(get_current_user)
):
    job = get_job_by_id(job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found"
        )
        
    if job["created_by"] != current_user["id"] and current_user["role"] != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to delete this job"
        )
        
    delete_job(job_id)
    return None
