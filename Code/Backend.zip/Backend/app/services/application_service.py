import uuid
from datetime import datetime
from app.models.application import ApplicationStatus
from app.services.job_service import get_job_by_id

# In-memory database for applications
applications_db = {}

def create_application(application_data, user_id):
    application_id = str(uuid.uuid4())
    
    # Check if job exists
    job = get_job_by_id(application_data["job_id"])
    if not job:
        return None
    
    new_application = {
        "id": application_id,
        "job_id": application_data["job_id"],
        "user_id": user_id,
        "proposed_budget": application_data["proposed_budget"],
        "proposed_deadline": application_data["proposed_deadline"],
        "cover_letter": application_data["cover_letter"],
        "status": ApplicationStatus.PENDING,
        "feedback": None,
        "created_at": datetime.now(),
        "updated_at": None
    }
    
    applications_db[application_id] = new_application
    return new_application

def update_application(application_id, application_data):
    if application_id not in applications_db:
        return None
        
    application = applications_db[application_id]
    
    for key, value in application_data.items():
        if value is not None:
            application[key] = value
    
    application["updated_at"] = datetime.now()
    return application

def get_application_by_id(application_id):
    return applications_db.get(application_id)

def get_applications_by_job(job_id, limit=10, offset=0):
    result = []
    for application in applications_db.values():
        if application["job_id"] == job_id:
            result.append(application)
            
    return result[offset:offset+limit]

def get_applications_by_user(user_id, limit=10, offset=0):
    result = []
    for application in applications_db.values():
        if application["user_id"] == user_id:
            result.append(application)
            
    return result[offset:offset+limit]
