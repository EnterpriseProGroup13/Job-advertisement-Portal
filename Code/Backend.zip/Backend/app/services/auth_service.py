import uuid
from datetime import datetime, timedelta
from typing import Optional
from app.utils.security import verify_password, get_password_hash, create_access_token
from app.models.user import UserRole

# In-memory database for users
users_db = {}
verification_codes = {}

def create_user(user_data):
    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash(user_data["password"])
    
    new_user = {
        "id": user_id,
        "first_name": user_data["first_name"],
        "surname": user_data["surname"],
        "email": user_data["email"],
        "phone_number": user_data["phone_number"],
        "country": user_data["country"],
        "city": user_data["city"],
        "password_hash": hashed_password,
        "role": user_data.get("role", UserRole.WORKER),
        "is_verified": False,
        "created_at": datetime.now()
    }
    
    users_db[user_id] = new_user
    
    # Create verification code
    code = str(uuid.uuid4())[:6]
    verification_codes[user_data["email"]] = code
    
    return new_user, code

def authenticate_user(email: str, password: str):
    user = get_user_by_email(email)
    if not user:
        return False
    if not verify_password(password, user["password_hash"]):
        return False
    if not user["is_verified"]:
        return None  # User needs to verify email
    return user

def get_user_by_email(email: str):
    for user in users_db.values():
        if user["email"] == email:
            return user
    return None

def get_user_by_id(user_id: str):
    return users_db.get(user_id)

def verify_email(email: str, code: str):
    if email not in verification_codes or verification_codes[email] != code:
        return False
    
    user = get_user_by_email(email)
    if not user:
        return False
    
    user["is_verified"] = True
    del verification_codes[email]
    return True
