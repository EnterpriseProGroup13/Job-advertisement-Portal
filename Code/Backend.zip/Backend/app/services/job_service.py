import uuid
from datetime import datetime
from app.models.job import JobStatus

# In-memory database for jobs
jobs_db = {}

def create_job(job_data, user_id):
    job_id = str(uuid.uuid4())
    
    new_job = {
        "id": job_id,
        "title": job_data["title"],
        "description": job_data["description"],
        "budget": job_data["budget"],
        "deadline": job_data["deadline"],
        "category": job_data["category"],
        "location_country": job_data["location_country"],
        "location_city": job_data["location_city"],
        "status": JobStatus.OPEN,
        "created_by": user_id,
        "created_at": datetime.now(),
        "updated_at": None
    }
    
    jobs_db[job_id] = new_job
    return new_job

def update_job(job_id, job_data):
    if job_id not in jobs_db:
        return None
        
    job = jobs_db[job_id]
    
    for key, value in job_data.items():
        if value is not None:
            job[key] = value
    
    job["updated_at"] = datetime.now()
    return job

def delete_job(job_id):
    if job_id not in jobs_db:
        return False
    del jobs_db[job_id]
    return True

def get_job_by_id(job_id):
    return jobs_db.get(job_id)

def get_jobs(filters=None, limit=10, offset=0):
    if filters is None:
        filters = {}
        
    result = []
    for job in jobs_db.values():
        match = True
        for key, value in filters.items():
            if key in job and job[key] != value:
                match = False
                break
        if match:
            result.append(job)
            
    return result[offset:offset+limit]
