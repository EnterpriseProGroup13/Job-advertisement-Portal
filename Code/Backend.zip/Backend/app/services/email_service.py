import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from app.config import settings

async def send_verification_email(email_to: str, verification_code: str):
    # For this implementation, we'll just print the code instead of actually sending an email
    # In a real implementation, you would use SMTP to send actual emails
    print(f"Sending verification email to {email_to} with code: {verification_code}")
    
    # Uncomment below for actual email sending implementation
    """
    message = MIMEMultipart()
    message["From"] = settings.EMAIL_FROM
    message["To"] = email_to
    message["Subject"] = "Verify your email address"
    
    body = f"Your verification code is: {verification_code}"
    message.attach(MIMEText(body, "plain"))
    
    try:
        server = smtplib.SMTP(settings.EMAIL_HOST, settings.EMAIL_PORT)
        server.starttls()
        server.login(settings.EMAIL_USERNAME, settings.EMAIL_PASSWORD)
        server.send_message(message)
        server.quit()
        return True
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False
    """
    return True
