from app.services.auth_service import get_user_by_id
from app.services.job_service import get_job_by_id
from app.models.application import ApplicationStatus

async def notify_application_status_change(application):
    """
    Send notification when application status changes.
    For this implementation, we'll just print the notification message.
    In a real system, this would send an email, push notification or store in a notification table.
    """
    job = get_job_by_id(application["job_id"])
    applicant = get_user_by_id(application["user_id"])
    job_creator = get_user_by_id(job["created_by"])
    
    status_messages = {
        ApplicationStatus.PENDING: "is now pending review",
        ApplicationStatus.ACCEPTED: "has been accepted",
        ApplicationStatus.REJECTED: "has been rejected",
        ApplicationStatus.COMPLETED: "has been marked as completed"
    }
    
    status_message = status_messages.get(application["status"], "has been updated")
    
    # Notify applicant
    applicant_message = f"Your application for job '{job['title']}' {status_message}."
    if application["feedback"]:
        applicant_message += f" Feedback: {application['feedback']}"
    print(f"Notification to {applicant['email']}: {applicant_message}")
    
    # Notify job creator (for pending applications)
    if application["status"] == ApplicationStatus.PENDING:
        job_creator_message = f"New application received for your job '{job['title']}' from {applicant['first_name']} {applicant['surname']}."
        print(f"Notification to {job_creator['email']}: {job_creator_message}")
    
    return True

async def notify_job_status_change(job, previous_status):
    """
    Send notification when job status changes.
    For this implementation, we'll just print the notification message.
    """
    job_creator = get_user_by_id(job["created_by"])
    
    status_messages = {
        "OPEN": "is now open for applications",
        "IN_PROGRESS": "has been moved to in-progress status",
        "COMPLETED": "has been marked as completed",
        "CANCELLED": "has been cancelled"
    }
    
    status_message = status_messages.get(job["status"], "has been updated")
    
    # Notify job creator
    message = f"Your job '{job['title']}' {status_message}."
    print(f"Notification to {job_creator['email']}: {message}")
    
    return True
