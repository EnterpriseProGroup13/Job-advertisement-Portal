from pydantic import BaseModel
from typing import Optional
from enum import Enum
from datetime import datetime

class ApplicationStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    COMPLETED = "completed"

class ApplicationCreate(BaseModel):
    job_id: str
    proposed_budget: float
    proposed_deadline: datetime
    cover_letter: str

class ApplicationUpdate(BaseModel):
    status: ApplicationStatus
    feedback: Optional[str] = None

class ApplicationResponse(BaseModel):
    id: str
    job_id: str
    user_id: str
    proposed_budget: float
    proposed_deadline: datetime
    cover_letter: str
    status: ApplicationStatus
    feedback: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
