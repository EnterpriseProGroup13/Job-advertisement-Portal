from pydantic import BaseModel, EmailStr
from typing import Optional
from enum import Enum
from datetime import datetime

class UserRole(str, Enum):
    ADMIN = "admin"
    CUSTOMER = "customer"  # Can post jobs
    WORKER = "worker"      # Can apply to jobs

class UserCreate(BaseModel):
    first_name: str
    surname: str
    email: EmailStr
    phone_number: str
    country: str
    city: str
    password: str
    role: UserRole = UserRole.WORKER

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    first_name: str
    surname: str
    email: EmailStr
    phone_number: str
    country: str
    city: str
    role: UserRole
    is_verified: bool
    created_at: datetime

class UserInDB(UserResponse):
    password_hash: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None
    role: Optional[UserRole] = None
