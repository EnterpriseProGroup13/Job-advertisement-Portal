from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum
from datetime import datetime

class JobStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class JobCategory(str, Enum):
    IT = "it_software"
    DESIGN = "design"
    WRITING = "writing"
    MARKETING = "marketing"
    CUSTOMER_SERVICE = "customer_service"
    OTHER = "other"

class JobCreate(BaseModel):
    title: str
    description: str
    budget: float
    deadline: datetime
    category: JobCategory
    location_country: str
    location_city: str

class JobUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    budget: Optional[float] = None
    deadline: Optional[datetime] = None
    category: Optional[JobCategory] = None
    location_country: Optional[str] = None
    location_city: Optional[str] = None
    status: Optional[JobStatus] = None

class JobResponse(BaseModel):
    id: str
    title: str
    description: str
    budget: float
    deadline: datetime
    category: JobCategory
    location_country: str
    location_city: str
    status: JobStatus
    created_by: str
    created_at: datetime
    updated_at: Optional[datetime] = None
