# System Architecture

This document describes the architecture and design of the Job Posting Website backend API.

## Overview

The system is built using Python FastAPI framework and follows a modular design pattern with clear separation of concerns. It implements a RESTful API for job postings, applications, and user management.

## Architecture Layers

### 1. API Layer (Controllers)

Located in the `/app/api` directory, this layer contains the route definitions and request handling logic. It's responsible for:
- Request validation
- Response formatting
- Authentication checks
- Route-specific logic

Components:
- `auth.py`: Authentication endpoints
- `jobs.py`: Job management endpoints
- `applications.py`: Application handling endpoints

### 2. Service Layer

Located in the `/app/services` directory, this layer contains the business logic of the application. It's responsible for:
- Implementing business rules
- Data processing
- Coordinating between different components

Components:
- `auth_service.py`: Authentication and user management logic
- `job_service.py`: Job creation and management logic
- `application_service.py`: Application processing logic
- `notification_service.py`: Notification handling logic
- `email_service.py`: Email sending logic

### 3. Model Layer

Located in the `/app/models` directory, this layer defines the data structures and validation rules using Pydantic models. It's responsible for:
- Data validation
- Schema definition
- Type checking

Components:
- `user.py`: User-related models
- `job.py`: Job-related models
- `application.py`: Application-related models

### 4. Middleware Layer

Located in the `/app/middlewares` directory, this layer contains cross-cutting concerns such as:
- Authentication middleware
- Role-based access control
- Request/response logging

Components:
- `auth_middleware.py`: JWT authentication and role checking

### 5. Utility Layer

Located in the `/app/utils` directory, this layer provides helper functions and utilities such as:
- Security utilities
- Common helper functions

Components:
- `security.py`: Password hashing and JWT token handling

## Data Flow

1. Client sends a request to an API endpoint
2. FastAPI routes the request to the appropriate controller
3. Authentication middleware validates the token if needed
4. Controller validates the request data using Pydantic models
5. Controller calls service layer functions with validated data
6. Service layer performs business logic and data operations
7. Service layer returns results to the controller
8. Controller formats and returns the response to the client

## Security Architecture

### Authentication

The API uses JWT (JSON Web Tokens) for authentication:

1. User registers and verifies their email
2. User logs in with credentials and receives a JWT token
3. Token is included in the Authorization header for subsequent requests
4. Auth middleware validates the token on protected routes

### Authorization

Role-based access control (RBAC) is implemented:

1. Each user has a role (worker, customer, admin)
2. Endpoints specify which roles are allowed to access them
3. Middleware checks if the authenticated user has the required role
4. Additional ownership checks ensure users can only modify their own resources

## In-Memory Data Storage

For this implementation, data is stored in memory using Python dictionaries:

- `users_db`: Stores user information
- `jobs_db`: Stores job listings
- `applications_db`: Stores job applications
- `verification_codes`: Stores email verification codes

In a production environment, these would be replaced with a proper database (MongoDB, PostgreSQL, etc.).

## Error Handling

The API implements a consistent error handling approach:

1. Input validation errors are handled automatically by FastAPI
2. Business logic errors return appropriate HTTP status codes
3. Custom exceptions are raised with descriptive messages
4. All errors follow a consistent JSON response format

## System Requirements

- Python 3.9+
- FastAPI
- Uvicorn (ASGI server)
- Pydantic
- Python-Jose (JWT handling)
- Passlib (Password hashing)

## Extensibility

The architecture is designed to be easily extensible:

1. New endpoints can be added by creating new router files
2. New models can be added to the models directory
3. Business logic can be extended in the services layer
4. Additional middleware can be added for cross-cutting concerns
