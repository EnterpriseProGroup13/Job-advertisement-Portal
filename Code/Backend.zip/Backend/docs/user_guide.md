# User Guide

This guide provides instructions on how to use the Job Posting Website API for different user roles.

## Getting Started

### Account Creation and Authentication

1. **Register a new account**

